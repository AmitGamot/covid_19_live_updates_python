#Design by: Amit Gomot
#Thankyou @Stackoverflow,@semicolonworld,@worldometers and @Google's YTS
def Scrap():
    def notifyme(title,message):
        plyer.notification.notify(
            title=title,
            message=message,
            app_icon = 'amit.ico',
            timeout=30
        )
    url = 'https://www.worldometers.info/coronavirus/'
    r = requests.get(url)
    soup = BeautifulSoup(r.content,'html.parser')
    tablebody = soup.find('tbody')
    tb1 = tablebody.find_all('tr')
    notifycountry = countrydata.get()
    if(notifycountry == ''):
        notifycountry = 'world'
    countries, total_cases, new_cases, total_deaths, new_deaths, total_recovered, active_cases = [], [], [], [], [], [], []
    serious, totalcases_permillion, totaldeaths_permillion, totaltests, totaltests_permillion = [], [], [], [], []
    headers = ['countries', 'total_cases', 'new_cases', 'total_deaths', 'new_deaths', 'total_recovered', 'active_cases',
               'serious', 'totalcases_permillion', 'totaldeaths_permillion', 'totaltests', 'totaltests_permillion']

    for i in tb1:
        id = i.find_all('td')
        if(id[0].text.strip().lower() == notifycountry):
            totalcases1 = int(id[1].text.strip().replace(',', ''))
            totaldeaths1 = id[3].text.strip()
            newcases1 = id[2].text.strip()
            #newdeaths1 = id[4].text.strip()
            total_recovered1 = id[5].text.strip()
            notifyme('Corona Virus Details In {}'.format(notifycountry),
                     'Total Cases : {}\nTotal Deaths : {}\nTotal Recovered : {}\nNew Cases : {}'.format(totalcases1,
                                                                                                   totaldeaths1,
                                                                                                   total_recovered1,
                                                                                                   newcases1))
        countries.append(id[0].text.strip())
        total_cases.append(int(id[1].text.strip().replace(',', '')))
        new_cases.append(id[2].text.strip())
        total_deaths.append(id[3].text.strip())
        new_deaths.append(id[4].text.strip())
        total_recovered.append(id[5].text.strip())
        active_cases.append(id[6].text.strip())
        serious.append(id[7].text.strip())
        totalcases_permillion.append(id[8].text.strip())
        totaldeaths_permillion.append(id[9].text.strip())
        totaltests.append(id[10].text.strip())
        totaltests_permillion.append(id[11].text.strip())
    df = pd.DataFrame(list(zip(countries, total_cases, new_cases,total_deaths, new_deaths, total_recovered, active_cases,serious,
                               totalcases_permillion, totaldeaths_permillion, totaltests, totaltests_permillion)),columns=headers)
    sor = df.sort_values('total_cases',ascending=False)
    for k in formatlist:
        if(k == 'html'):
            path2 = '{}/coronavirus-data.html'.format(path)
            sor.to_html(r'{}'.format(path2))
        if(k == 'json'):
            path2 = '{}/coronavirus-data.json'.format(path)
            sor.to_json(r'{}'.format(path2))
        if(k == 'csv'):
            path2 = '{}/coronavirus-data.csv'.format(path)
            sor.to_csv(r'{}'.format(path2))
    if(len(formatlist) !=0):
        messagebox.showinfo("Notification",'Coronavirus data saved sucessfully! {}'.format(path2),parent=root)


def download():
    global path
    if(len(formatlist) != 0):
        path = filedialog.askdirectory()
    else:
        pass
    Scrap()
    formatlist.clear()
    InHtml.configure(state='normal')
    InJson.configure(state='normal')
    InCsv.configure(state='normal')

def inhtml():
    formatlist.append('html')
    InHtml.configure(state='disabled')
def incsv():
    formatlist.append('csv')
    InCsv.configure(state='disabled')
def injson():
    formatlist.append('json')
    InJson.configure(state='disabled')
def callback(url1):
    webbrowser.open_new(url1)    

import plyer
import requests
from bs4 import BeautifulSoup
import pandas as pd
from tkinter import *
from tkinter import messagebox,filedialog
import webbrowser
root = Tk()
root.title('Covid19 live updates 1.0')
photo = PhotoImage(file = "Coronavirus.png")
w = Label(root, image=photo)
w.pack()
root.geometry('630x400+300+180')
root.iconbitmap('amit.ico')
formatlist = []
path = ''
#  Labels
IntroLabel = Label(root,text='Covid19 Updates',font=('new roman',30,'italic bold'),bg='white',width=15)
IntroLabel.place(x=128,y=0)

EntryLabel = Label(root,text='Country Name :',font=('arial',20,'italic bold'),bg='plum2')
EntryLabel.place(x=30,y=100)

FormatLabel = Label(root,text='Download Data :',font=('arial',20,'italic bold'),bg='plum2')
FormatLabel.place(x=30,y=180)

# Entry
countrydata = StringVar()
ent1 = Entry(root,textvariable=countrydata,font=('arial',20,'italic bold'),relief=RIDGE,bd=2,width=20)
ent1.place(x=240,y=100)
#  Buttons
InHtml = Button(root,text='Html',foreground='green',font=('arial',14,'italic bold'),relief=RIDGE,activebackground='blue',activeforeground='white',
                bd=2,width=5,command=inhtml)
InHtml.place(x=270,y=180)

InJson = Button(root,text='Json',foreground='green',font=('arial',14,'italic bold'),relief=RIDGE,activebackground='blue',activeforeground='white',
                bd=2,width=5,command=injson)
InJson.place(x=370,y=180)

InCsv = Button(root,text='Csv',foreground='green',font=('arial',14,'italic bold'),relief=RIDGE,activebackground='blue',activeforeground='white',
                bd=2,width=5,command=incsv)
InCsv.place(x=470,y=180)

Submit = Button(root,text='Send Notification',foreground='white',bg='red',font=('arial',15,'italic bold'),relief=RIDGE,activebackground='blue',activeforeground='white',
                bd=3,width=25,command=download)
Submit.place(x=150,y=280)

link1 = Label(root, text=" Click here!, for more updates on Covid19 ", fg="blue", cursor="hand2")
link1.place(x=200,y=350)
link1.bind("<Button-1>", lambda e: callback("https://www.worldometers.info/coronavirus/"))
root.mainloop()